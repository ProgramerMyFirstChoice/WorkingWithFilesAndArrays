﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkingWithFilesAndArrays
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnListFolders_Click(object sender, EventArgs e)
        {
            // Create a string variable array named dirs to hold
            // the directory entries for the special folders program Files
            string[] dirs = Directory.GetDirectories(Environment.GetFolderPath
                                        (Environment.SpecialFolder.ProgramFiles));

            // Loop thru the array of folders and add them to the listDisplay box 
            // using the Items.Add method.
            foreach (string dir in dirs)
            {
                listDisplay.Items.Add(dir);
            }


        }

        private void btnListFiles_Click(object sender, EventArgs e)
        {
            // Clear the listDisplay box
            listDisplay.Items.Clear();

            // Create a string variable array named files to hold
            // the directory and file entries
            // For special folder My Documents
            string[] files = Directory.GetFileSystemEntries(Environment.GetFolderPath
                                        (Environment.SpecialFolder.Personal));

            // Loop thru the array of files and folders and add them to the 
            // listDisplay box using the Items.Add method.
            foreach(string file in files)
            {
                listDisplay.Items.Add(file);
            }

        }

        private void btnWriteToFile_Click(object sender, EventArgs e)
        {
            try
            {
                // Create an array with some values
                int[] numbers = { 10, 20, 30, 40, 50 };

                // Declare a StreamWriter variable
                StreamWriter outputFile;

                // Create a file and get a StreamWriter object.
                outputFile = File.CreateText(@"C:\Users\nngebreyohannies\Documents\FilesCS.txt");

                // Write the array's content to the file.
                for (int i = 0; i < numbers.Length; i++)
                {
                    outputFile.WriteLine(numbers[i]);
                }

                // Close the StreamWriter
                outputFile.Close();

                // Let the user know the array values was written
                MessageBox.Show("Done");
            }
            catch (Exception ex)
            {
                // Display an error Message
                MessageBox.Show(ex.Message); ;
            }
            

        }

        private void btnReadFromFile_Click(object sender, EventArgs e)
        {
            try
            {
                // Clear the listDisplay box
                listDisplay.Items.Clear();

                // Create an array to hold items read from the file
                const int SIZE = 6;
                int[] numbersFromFile = new int[SIZE];

                // Create a new StreamReader and pass the file created
                // in the WriteToFile_Click event
                StreamReader inputFile = File.OpenText(@"C:\Users\nngebreyohannies\Documents\FilesCS.txt");

                // Counter variable to use in the loop
                int index = 0;

                // Read the file's contents into the array
                while (index < numbersFromFile.Length && !inputFile.EndOfStream)
                {
                    numbersFromFile[index] = int.Parse(inputFile.ReadLine());
                    index++;
                }

                // Close the StreamReader
                inputFile.Close();

                // Display the array elements in the listDisplay box
                foreach (int value in numbersFromFile)
                {
                    listDisplay.Items.Add(value + "");
                }
            }
            catch (Exception ex)
            {
                // Display an error message
               MessageBox.Show(ex.Message);
            }
           
        }
    }
}
